#!/bin/sh

make -s 2>/dev/null
