/* XPM */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMmth_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 10 1 0 0",
/* colors */
"     s mask    m black c #949494949494",
".	s iconColor1	m black	c black",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor2	m white	c white",
"O    s iconGray5     m black c #737373737373",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray1     m white c #dededededede",
"#    s iconGray3     m white c #adadadadadad",
"$    s iconGray8     m black c #212121212121",
"%	s iconColor5	m black	c blue",
/* pixels */
"     .            .     ",
"    .X.          .X.    ",
"  ...o............o...  ",
"  .o.o.oooooooooo.o.O.  ",
"  .o.+.@@@@@@@@@@.+.#.  ",
"  $o@.@@@@@@@@@@@@.@#.  ",
"  $o@@@@@@@@@@@@@@@@#$  ",
"  $o@@@@@@@@@@@@@@@@#$  ",
"  $o@@#%#%#%#%#%#%@@#$  ",
"  $o@@%#%#%#%#%#%#@@#$  ",
"  $o@@#%#%#%#%#%#%@@#$  ",
"  $o@@%#%#%#%#%#%#@@#$  ",
"  $o@@#%#%#%#%#%#%@@#$  ",
"  $o@@%#%#%#%#%#%#@@#$  ",
"  $o@@#%#%#%#%#%#%@@#$  ",
"  $o@@%#%#%#%#%#%#@@#$  ",
"  $o@@#%#%#%#%#%#%@@#$  ",
"  $o@@%#%#%#%#@@@@@@#$  ",
"  $o@@#%#%#%#%@@@@@@#$  ",
"  $o@@@@@@@@@@@@@@@@#$  ",
"  $o@@@@@@@@@@@@@@@@#$  ",
"  $o#################$  ",
"  $$$$$$$$$$$$$$$$$$$$  ",
"                        "};
